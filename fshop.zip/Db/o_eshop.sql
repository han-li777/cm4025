﻿# Host: localhost  (Version: 5.7.26)
# Date: 2021-03-20 21:23:19
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "active"
#

DROP TABLE IF EXISTS `active`;
CREATE TABLE `active` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `teamname` varchar(255) DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `peoplename` varchar(255) DEFAULT NULL,
  `adr` varchar(255) DEFAULT NULL,
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='活动表';

#
# Data for table "active"
#

/*!40000 ALTER TABLE `active` DISABLE KEYS */;
INSERT INTO `active` VALUES (2,'经济管理系诗社朗诵大赛','经济管理系诗社','1612108800','1612454400','张莉','经管系一号教学楼','2021-02-01 15:42:12'),(3,'物理知识竞赛','数学系物理社','1612108800','1614096000','王多多','经管系一号教学楼','2021-02-01 15:44:03');
/*!40000 ALTER TABLE `active` ENABLE KEYS */;

#
# Structure for table "auth"
#

DROP TABLE IF EXISTS `auth`;
CREATE TABLE `auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leftid` int(11) DEFAULT NULL COMMENT '侧边栏id',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限表';

#
# Data for table "auth"
#

INSERT INTO `auth` VALUES (1,1,1,'2020-12-02 17:03:57'),(2,2,1,'2020-12-02 17:34:26');

#
# Structure for table "borad"
#

DROP TABLE IF EXISTS `borad`;
CREATE TABLE `borad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `borad` text,
  `name` varchar(255) DEFAULT NULL,
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# Data for table "borad"
#

/*!40000 ALTER TABLE `borad` DISABLE KEYS */;
INSERT INTO `borad` VALUES (1,'我的留言1','游客48166','2021-02-01 17:22:29'),(2,'我的留言2','游客29628','2021-02-01 17:23:52'),(3,'我的留言3','游客19558','2021-02-01 17:23:59');
/*!40000 ALTER TABLE `borad` ENABLE KEYS */;

#
# Structure for table "car"
#

DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goodisid` varchar(255) DEFAULT NULL,
  `goodsname` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `shopid` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Data for table "car"
#

/*!40000 ALTER TABLE `car` DISABLE KEYS */;
/*!40000 ALTER TABLE `car` ENABLE KEYS */;

#
# Structure for table "comment"
#

DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teamname` varchar(255) DEFAULT NULL,
  `comment` text,
  `peoplename` varchar(255) DEFAULT NULL,
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# Data for table "comment"
#

/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (2,'美术系美术社团','我的评价2','张莉','2021-02-01 16:58:02','好评'),(3,'经济管理系诗社','我的评价1','王多多','2021-02-01 16:58:19','中评');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;

#
# Structure for table "goods"
#

DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `imgurl` varchar(255) DEFAULT 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1066879593,2077363655&fm=26&gp=0.jpg' COMMENT '图片地址',
  `inctro` varchar(255) DEFAULT NULL COMMENT '介绍',
  `shopid` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `stock` varchar(255) DEFAULT '193',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `zhek` varchar(255) DEFAULT '0',
  `juan` varchar(255) DEFAULT '0',
  `zknum` varchar(255) DEFAULT '123456',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='商品表';

#
# Data for table "goods"
#

/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (7,'goods 41222','fd935557e779213e49ffd4bcbca66a5e.jpg','test goods infomations','1','12','175','2021-03-13 16:30:54','2021-03-13 16:35:39',NULL,NULL,NULL),(8,'goods 91128','d4f5185539cb2e83c3ca13f7a88b1dc2.jpg','test goods infomations 1','1','20','199','2021-03-13 16:36:01',NULL,NULL,NULL,NULL),(9,'goods 13402','7383fdcd1447dd9e08c67dd9b3274ba1.jpg','test goods infomations 2','1','35','68','2021-03-13 16:37:00',NULL,NULL,NULL,NULL),(10,'goods 24081','d5b45022a5433069a94f11a4d9fbee4d.jpg','test goods infomations 3','1','20','185','2021-03-13 16:37:11',NULL,NULL,NULL,NULL),(11,'goods 60220','5c65ed87f5734f40ecb9845efe87d245.jpg','test goods infomations 4','1','35','114','2021-03-13 16:37:27',NULL,NULL,NULL,NULL),(12,'goods 85745','bebbcf05d861a3e284851f16b16ccace.jpg','test goods infomations 5','1','12','139','2021-03-13 16:37:37',NULL,NULL,NULL,NULL),(13,'goods 51975','a7fc262858e6d275a0b2e799b0188318.jpg','test goods infomations 6','1','50','48','2021-03-20 21:11:57',NULL,'8','10',NULL),(14,'goods 60615','6b26eb9d5193dad784f12b8a0bc0afd2.jpg','test goods infomations 7','1','50','159','2021-03-20 21:18:01',NULL,'8','10','86584');
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;

#
# Structure for table "order"
#

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sn` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `goodis` varchar(255) DEFAULT NULL,
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userid` varchar(255) DEFAULT NULL,
  `shopid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

#
# Data for table "order"
#

/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,'16157720963262','35','9','2021-03-15 09:34:56','19','1'),(2,'16157721029824','20','10','2021-03-15 09:35:02','19','1'),(3,'16157728445258','35','9','2021-03-15 09:47:24','21','1'),(4,'16157728507288','35','11','2021-03-15 09:47:30','21','1'),(5,'16157728547221','35','11','2021-03-15 09:47:34','21','1'),(6,'16162465109625','40','14','2021-03-20 21:21:50','19','1');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;

#
# Structure for table "team"
#

DROP TABLE IF EXISTS `team`;
CREATE TABLE `team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `belong` varchar(250) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '从属',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='社团表';

#
# Data for table "team"
#

/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (1,'计算机唱歌社团255','1','2021-02-01 12:11:08','2021-02-18 17:37:29'),(2,'经济管理系诗社','2','2021-02-01 12:11:33','2021-02-18 15:52:59'),(3,'美术系美术社团','3','2021-02-01 12:11:46','2021-02-18 15:53:01'),(5,'数学系物理社','4','2021-02-01 12:12:04','2021-02-18 15:53:04');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;

#
# Structure for table "user"
#

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL COMMENT '唯一标识码',
  `rank` int(11) DEFAULT '1' COMMENT '1 客服 2管理',
  `class` varchar(255) DEFAULT 'A班' COMMENT '班级',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `post_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT '1' COMMENT '1 未启用 2启用',
  `belong` varchar(255) DEFAULT NULL COMMENT '所属',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户客服表';

#
# Data for table "user"
#

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','e10adc3949ba59abbe56e057f20f883e',1,'A班','2020-12-01 21:42:09','2021-03-13 15:52:03',2,NULL),(17,'test5','e10adc3949ba59abbe56e057f20f883e',1,'A班','2020-12-14 10:11:47','2021-03-13 15:51:56',1,NULL),(19,'test','e10adc3949ba59abbe56e057f20f883e',0,'A班','2021-02-18 12:01:32',NULL,2,NULL),(21,'test1','e10adc3949ba59abbe56e057f20f883e',0,'A班','2021-02-18 17:53:00',NULL,1,NULL),(22,'test2','e10adc3949ba59abbe56e057f20f883e',0,'A班','2021-02-18 17:55:56',NULL,1,NULL),(23,'test','e10adc3949ba59abbe56e057f20f883e',0,'A班','2021-02-24 09:12:10',NULL,2,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
