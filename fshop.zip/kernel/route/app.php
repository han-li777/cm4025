<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\facade\Route;

//miss
Route::miss('findex/index');
//indexpage
Route::get('/', 'findex/index');
//错误路由
Route::any("/error", 'error/error');
//正确路由
Route::any('/success', 'success/success');

Route::group('index', function () {

    Route::get('/index', 'findex/index');
    Route::get('', 'findex/index');
    Route::get('/goods','findex/goods');
    Route::get('/q','findex/q');
    Route::get('/reg','findex/reg');
    Route::get('/login', 'findex/login');
    Route::post('/rega','findex/rega');
    Route::post('/logina', 'findex/logina');
    Route::get('/logout', 'findex/logout');
    Route::get('/usercenter', 'findex/usercenter');
    Route::get('/incar', 'findex/incar');
    Route::get('/clearcar', 'findex/clearcar');
    Route::get('/buy','findex/buy');
    Route::get('/goodsinfo', 'findex/goodsinfo');
    Route::get('/del_car', 'findex/delCar');
});
   
    Route::get('/admin', 'index/index');

    Route::get('/adminindex', 'index/adminindex');
    Route::get('/list', 'index/welcome');
    Route::post('/login', "user/login");
    Route::get('/logout', 'user/logout');

    Route::get('/add', 'index/add');
    Route::get('/addreg', 'user/addreg');
    Route::post('/addin', 'user/addIn');
    Route::get('/deluser', 'user/delUser');

    Route::post('/addteam', 'index/addTeam');
    Route::get('/delteam', 'index/delTeam');
    
    Route::get('/active','active/index');
    Route::post('/addactive', 'active/add');
    Route::get('/delactive', 'active/delactive');

    Route::get('/comment', 'comment/index');
    Route::get('/delcomment', 'comment/delcomment');
    Route::post('/addcomment', 'comment/addcomment');
    
    Route::get('/goods', 'commentborad/index');
    Route::post('/addgoods', 'commentborad/addborad');
    Route::get('/delgoods', 'commentborad/delgoods');
