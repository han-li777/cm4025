<?php
namespace app;

// 应用plase求对象类
class Request extends \think\Request
{

}
