<?php
namespace app\controller;

use app\controller\Base;
use think\facade\Db;
use think\facade\Request;

class Index extends Base
{
    /**
     * indexpage
     */
    public function index(){
        
        return view('admin/index/welcome',$this->ret)->filter($this->filter);
    }
    public function adminindex(){

        $userArr = [];

        $userLe = [];

        $userAe = [];

        $order = Db::table("order")->select();

        if(!empty($order)){
            foreach( $order as $key=>$val){
                $userArr[$val['userid']] = $val['userid'];
            }
        }

        $userCount = Db::table("user")->count();

        $this->ret['userlv'] = ($userCount == 0) ? 0 : round(count($userArr) / $userCount, 2) * 100;

        $user = Db::table("user")->where(["rank"=>0])->select();

        if(!empty($user)){
            foreach( $user as $k=>$v){
                $orderCount = Db::table("order")->where(["userid"=>$v['id']])->count();
                $userLe[] = $orderCount;
                $userAe[] = $v['name'];
            }
        }

        $this->ret['userle'] = implode(",",$userLe);
        $this->ret['userae'] = "'" . implode("','",$userAe) . "'";

        return view('admin/index/adminindex', $this->ret)->filter($this->filter);
    }
    /**
     * 欢迎page
     */
    public function welcome(){

        $q = Request::param("q","");

        $pageRe = 15;

        $where = [];

        if($q != ""){

            $where[] = ["name","like","%".(string)trim($q)."%"];
        }

        $list = Db::table("team")->where($where)->order('id','desc')->paginate($pageRe);

        $this->ret['page'] = $list->render();

        $this->ret['items'] = $list->items();

        return view('admin/index/index',$this->ret)->filter($this->filter);
    }
    /**
     *  add 团队
     *
     * @return void
     */
    public function addTeam(){

        $data = Request::param();

        $res = Db::table("team")->insert($data);

        if($res){

            Base::redirect(url('/success'), url("/list"), "add  success!！", "社团list page");
        }else{

            Base::redirect(url('/error'), url("/list"), "add fail！", "社团list page");
        }
    }
    /**
     * delete
     *
     * @return void
     */
    public function delTeam(){

        $id = Request::param("id");

        $res = Db::table("team")->where(["id"=>$id])->delete();

        if ($res) {

            Base::redirect(url('/success'), url("/list"), "delete success!！", "社团list page");
        } else {

            Base::redirect(url('/error'), url("/list"), "deletefail！", "社团list page");
        }
    }
    /**
     *  add 
     */
    public function add(){

        return view('admin/index/add',$this->ret)->filter($this->filter);
    }
}
