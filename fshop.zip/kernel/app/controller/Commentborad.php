<?php
namespace app\controller;

use app\controller\Base;
use think\facade\Db;
use think\facade\Request;

class Commentborad extends Base
{
    public $goods = [
        "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3136444425,4268006721&fm=26&gp=0.jpg",
        "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3044154774,1617735530&fm=26&gp=0.jpg",
        "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3569914470,3700538102&fm=26&gp=0.jpg",
        "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3866707755,1012171439&fm=26&gp=0.jpg",
        "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg2.tbcdn.cn%2Ftfscom%2Fi1%2FT1aDyeXhtxXXXv_p6c_125653.jpg_310x310.jpg&refer=http%3A%2F%2Fimg2.tbcdn.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1616231121&t=3de0cffd0093dd17874d08dd2097efae",
        "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fwww.szthks.com%2Flocalimg%2F687474703a2f2f6777312e616c6963646e2e636f6d2f62616f2f75706c6f616465642f69312f54316d4779315875585858585858585858585f2121302d6974656d5f7069632e6a7067.jpg&refer=http%3A%2F%2Fwww.szthks.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1616231121&t=b13a33926c39597978c4ea42bd6f183d"
    ];
    /**
     * index
     */
    public function index(){

        $data = Db::table("goods")->where(["shopid"=>$this->shopins['id']])->order("id desc")->select();

        $this->ret['goods'] = $data;

        return view('admin/commentborad/index', $this->ret)->filter($this->filter);
    }
    /**
     * addborad
     */
    public function addborad(){

        $data = Request::param();

        if (!empty($_FILES['file'])) {

            $file = $_FILES['file'];
            $url = md5(time() . rand(100, 999)) . ".jpg";
            $das = file_get_contents($file['tmp_name']);
            file_put_contents($url, $das);
            $data['imgurl'] = $url;
        }

        unset($data['file']);

        $data['zknum'] = rand(10000,99999);

        $data['shopid'] = $this->shopins['id'];

        $res = Db::table("goods")->insert($data);

        if ($res) {

            Base::redirect(url('/success'), url("/goods"), "add  success!！", "goods list page",1);
        } else {

            Base::redirect(url('/error'), url("/goods"), "add fail！", "goods list page",1);
        }
    }
    public function delgoods(){

        $id = Request::param("id");

        $res = Db::table("goods")->where(["id" => $id])->delete();

        if ($res) {

            Base::redirect(url('/success'), url("/goods"), "delete success!！", "goods list page");
        } else {

            Base::redirect(url('/error'), url("/goods"), "deletefail！", "goods list page");
        }
    }
}