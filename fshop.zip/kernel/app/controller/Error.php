<?php
namespace app\controller;

use app\controller\Base;
use think\facade\Request;

class Error extends Base
{
    /**
     * 错误page面
     */
    public function error(){

        $this->ret['goUrl'] = Request::param("goUrl");
        $this->ret['message'] = Request::param("message");
        $this->ret['adrUrl'] = Request::param("adrUrl");
        $this->ret['goTime'] = Request::param("goTime");

        return view('admin/status/error',$this->ret)->filter($this->filter);
    }
}