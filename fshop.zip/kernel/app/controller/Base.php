<?php
namespace app\controller;

use think\facade\Db;
use think\Request;

use think\facade\Session;

class Base{

    public $master_name = "user";
    
    public $master_pwd = "c93a0bcb020b85807e6f147db9b51762";

    public $ret = array();

    public $page = 1;

    public $pagel = 10;

    public $req;

    public $csrf;

    public $jwt;

    public $filter;

    public $pathInfo;

    /**
     * 中间检查
     */
    public function __construct(){ 
        
        if(!isset($_SESSION[$this->master_name])){

            $_SESSION[$this->master_name] = "";
        }

        $pathInfoArr = explode("?",$_SERVER['REQUEST_URI']);

        $pathInfo = current($pathInfoArr);

        $pathTemp = explode("/",$pathInfo);

        $pathTes = current(array_reverse($pathTemp));
        
        $list = array("list"=>array(),"top"=>array(),"adr"=>$pathTes);

        //指定路径
        $this->pathInfo = $pathInfo;

        $this->ret['usertitle'] = "";

        //侧边栏
        $this->ret['left'] = [
                                ["path" => "/adminindex", "name" => "adminindex", "adr" => "adminindex", "rank" => 1],
                                ["path"=>"/active","name"=>"user list","adr"=> "active", "rank" => 1],
                                ["path"=> "/comment","name" => "order management", "adr" => "comment","rank" =>1],
                                ["path" => "/goods", "name" => "goods info management", "adr" => "goods","rank" => 1],
                            ];

        $this->ret['top'] = $list['top'];

        $this->ret['route_path'] = $pathInfo;

        $this->ret['adr'] = $list['adr'];

        $this->ret['page'] = $this->page;

        $this->ret['pagel'] = $this->pagel;

        $this->ret['month'] = date("Y-m");

        $this->uid = $_SESSION[$this->master_name];

        $this->req = new Request();

        //返回原地址
        $backUrl = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

        $this->ret['backurl'] = $backUrl;

        //根地址
        $rootUrl = 'http://' . $_SERVER['HTTP_HOST'];

        $rootUrlArr = explode("/public/",$backUrl);

        $rootAdr = $rootUrlArr[0]."/public/";

        $this->ret['rootadr'] = $rootAdr;

        $this->ret['rooturl'] = $rootUrl;

        $this->ret['webtitle'] = "eshop-EBW";

        $user = Db::table("user")->where(["id"=>$this->uid])->find();

        $this->rank = $user['rank'];

        $this->ret['rank'] = $user['rank'];

        $this->shopins = Db::table("team")->where(["belong"=>$user['id']])->find();

        $this->ret['shops'] = $this->shopins;

        // if($user['rank'] == "0"){
        //     Base::redirect(url('/error'), url("index/index"), "rankNot enough！", "indexpage");
        // }
    }
    /**
     * 重定向
     */
    public static function redirect($url,$goUrl = "/",$message="You need Login!",$adrUrl = "Index",$goTime = 3){
        $url = $url."?goUrl=".$goUrl."&message=".$message."&adrUrl=".$adrUrl."&goTime=".$goTime;
        header("Location: $url");
        exit();
    }
    /**
     * 输出json
     */
    public static function outPut($code=200,$msg= "operate success!"){
        echo json_encode(["code"=>$code,"msg"=>$msg],true);
        exit();
    }
    /**
     * 返回数据集
     */
    public static function location($backUrl,$res=1,$alert= "operate fail!"){

        Session::flash('action_status',$res);
        Session::flash('action_alert',$alert);

        header("Location:$backUrl");
    }
    /**
     * 生成csv文件
     */
    public static function exportCsv($data,$head,$filename)
    {
        /**
         * 开始生成
         * 1. index先将数组拆分成以逗code（注意需要英文）分割的字符串
         * 2. 然后加上每行的换行符code，这里建议直接使用PHP的预定义
         * 常量PHP_EOL
         * 3. 最后写入文件
         */
        // 打开文件资源，不存在则create
        $fp = fopen($filename.'.csv','w+');
        // 处理头部标题
        $header = implode(',', $head) . PHP_EOL;
        // 处理内容
        $content = '';
        foreach ($data as $k => $v) {
        $content .= implode(',', $v) . PHP_EOL;
        }
        // 拼接
        $csv = $header.$content;
        // 写入并关闭资源
        fwrite($fp, $csv);
        fclose($fp);
        
        return $filename.".csv";
    }
    /**
     * 字符转换（utf-8 => GBK）
     */
    public static function utfToGbk($data)
    {
        return iconv('utf-8', 'GBK', $data);
    }
}
