<?php
namespace app\controller;

use app\controller\Base;
use think\facade\Db;
use think\facade\Request;

class Comment extends Base
{
    /**
     * index
     */
    public function index(){

        $pageRe = 15;

        $where = [];

        if($this->rank == 1){

            $where["shopid"] = $this->shopins['id'];
        }

        $list = Db::table("order")->where($where)->order('id', 'desc')->paginate($pageRe);

        $this->ret['page'] = $list->render();

        $order = $list->items();

        if (!empty($order)) {
            foreach ($order as $key => $val) {
                $goodstr = [];
                $goodsids = explode('|', $val['goodis']);
                if (!empty($goodsids)) {
                    foreach ($goodsids as $k => $v) {
                        if (!empty($v)) {
                            $good = Db::table("goods")->where(["id" => $v])->find();
                            $goodstr[] = $good['name'];
                        }
                    }
                }
                $order[$key]['goodis'] = implode('|', $goodstr);
            }
        }

        $this->ret['items'] = $order;
        
        return view('admin/comment/index', $this->ret)->filter($this->filter);
    }
    /**
     * delcomment
     */
    public function delcomment(){

        $id = Request::param("id");

        $res = Db::table("order")->where(["id" => $id])->delete();

        if ($res) {

            Base::redirect(url('/success'), url("/comment"), "delete success!！", "orderlist page");
        } else {

            Base::redirect(url('/error'), url("/comment"), "deletefail！", "orderlist page");
        }
    }
}