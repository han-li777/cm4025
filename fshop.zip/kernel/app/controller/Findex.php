<?php
namespace app\controller;

use app\controller\Base;
use think\facade\Db;
use think\facade\Request;

class Findex extends Base
{
    public function index(){

        $goods = Db::table("goods")->limit(15)->select()->toArray();

        $this->ret['goods'] = $goods;

        return view('findex/index', $this->ret)->filter($this->filter);
    }
    public function goods(){

        $goods = Db::table('goods')->order('id', 'desc')->paginate(10);

        $this->ret['goods'] = $goods;

        return view('findex/goods',$this->ret)->filter($this->filter);
    }
    public function q(){

        $q = Request::param("q","");

        $goods = ($q == "")?[]:Db::table("goods")->where([["name","like","%".(string)trim($q)."%"]])->select()->toArray();

        $this->ret['goods'] = $goods;

        return view('findex/q', $this->ret)->filter($this->filter);
    }
    public function shops(){

        $shops = Db::table("team")->order('id', 'desc')->paginate(10);

        $this->ret['shops'] = $shops;

        return view('findex/shops',$this->ret)->filter($this->filter);
    }
    public function reg(){

        $type = Request::param("type","0");

        $this->ret['type'] = $type;

        return view('findex/reg', $this->ret)->filter($this->filter);
    }
    public function login(){

        return view('findex/login', $this->ret)->filter($this->filter);
    }
    public function rega(){

        $username = Request::param("username");
        $password = Request::param("password");
        $type = Request::param("type","0");

        $user = Db::table("user")->where(['name' => $username])->find();

        if (!empty($user)) {

            Base::redirect(url('/error'), url("index/reg"), "have same username！plase change other name!", "registerpage");
        }

        $res = Db::table("user")->insert(["name"=>$username,"pwd"=>md5($password),"rank"=>$type,"status"=>2]);

        if($res){
            Base::redirect(url('/success'), url("index/login"), "register success!！", "loginpage", 1);
        }else{
            Base::redirect(url('/error'), url("index/reg"), "registerfail！", "registerpage", 1);
        }
    }
    public function logina(){

        $username = Request::param("username");
        $password = Request::param("password");

        $data = Db::table("user")->where(["name" => $username])->find();
        if(empty($data)){
            $res = false;
        }else{
            if($data['pwd']==md5($password)){
                $_SESSION['logins'] = ["id"=>$data['id'],"name"=>$data['name'],"rank"=>$data['rank']];
                $res = true;
            }else{
                $res = false;
            }
        }
        if ($res) {
            Base::redirect(url('/success'), url("index/login"), "login success!！", "indexpage", 1);
        } else {
            Base::redirect(url('/error'), url("index/login"), "loginfail！", "loginpage", 1);
        }
    }
    public function logout(){

        unset($_SESSION['logins']);
        Base::redirect(url('/success'), url("index/"), " logout  success!！", "indexpage", 1);
    }
    public function usercenter(){

        $this->checkS();

        $this->ret['username'] = $_SESSION['logins']['name'];
        $this->ret['id'] = $_SESSION['logins']['id'];

        $car = Db::table("car")->where(["userid"=>$_SESSION['logins']['id']])->select()->toArray();

        $this->ret['car'] = $car;

        $order = Db::table("order")->where(["userid"=>$_SESSION['logins']['id']])->select()->toArray();

        if(!empty($order)){
            foreach($order as $key=>$val){
                $goodstr = [];
                $goodsids = explode('|',$val['goodis']);
                if (!empty($goodsids)) {
                    foreach ($goodsids as $k=>$v) {
                        if(!empty($v)){
                            $good = Db::table("goods")->where(["id" =>$v])->find();
                            $goodstr[] = $good['name'];
                        }
                    }
                }
                $order[$key]['goodis'] = implode('|',$goodstr);
            }
        }

        $this->ret['order'] = $order;

        return view('findex/usercenter', $this->ret)->filter($this->filter);
    }
    public function checkS(){

        if(!isset($_SESSION['logins'])){

            Base::redirect(url('/error'), url("index/login"), "plaselogin！", "indexpage", 1);
        }
    }
    public function incar(){

        $this->checkS();
        
        $add['goodisid'] = Request::param("goodisid");
        $add['goodsname'] = Request::param("goodsname");
        $add['price'] = Request::param("price");
        $add['shopid'] = Request::param("shopid");
        $add['userid'] = $_SESSION['logins']['id'];

        Db::table("car")->insert($add);

        Base::redirect(url('/success'), url("index/usercenter"), "ADDTOCART success!！", "car ", 1);
    }
    public function clearcar(){

        $this->checkS();

        $car = Db::table("car")->where(["userid"=>$_SESSION['logins']['id']])->select()->toArray();

        if(empty($car)){
            Base::redirect(url('/error'), url("index/usercenter"), "car 为空", "car ", 1);
        }

        $goodis = "";
        foreach($car as $key=>$val){

            $price[]  = $val['price'];
            $goodis = $goodis."|".$val['goodisid'];
        }

        Db::table("order")->insert([
                                    "sn"=>time().rand(1000,9999),
                                    "price"=>array_sum($price),
                                    "goodis"=>$goodis,
                                    "userid"=>$_SESSION['logins']['id'],
                                    "shopid"=>"0"
                                ]);

        Db::table("car")->where(["userid" => $_SESSION['logins']['id']])->delete();

        Base::redirect(url('/success'), url("index/usercenter"), "结算 success!！", "car ", 1);
    }
    public function buy(){

        $this->checkS();

        $goods = Db::table("goods")->where(["id"=> Request::param("goodisid")])->find();

        $priceArr[] = $goods['price']*($goods['zhek']/10);
        $priceArr[] = $goods['price']-$goods['juan'];

        $add['sn'] = time().rand(1000,9999);
        $add['goodis'] = Request::param("goodisid");
        $add['price'] = min($priceArr);
        $add['userid'] = $_SESSION['logins']['id'];
        $add['shopid'] = $goods['shopid'];

        Db::table("order")->insert($add);

        Base::redirect(url('/success'), url("index/usercenter"), "BUY success!！", "people center page", 1);
    }
    public function qs(){

        $q = Request::param("qs", "");

        $shops = ($q == "") ? [] : Db::table("team")->where([["name", "like", "%" . (string)trim($q) . "%"]])->paginate(10);

        $this->ret['shops'] = $shops;

        return view('findex/qs', $this->ret)->filter($this->filter);
    }
    public function shopinfo(){

        $id = Request::param("id");

        $this->ret['shop'] = Db::table("team")->where([["id", "=", $id]])->find();

        $this->ret['goods'] = Db::table("goods")->where([["shopid","=",$id]])->select()->toArray();

        return view('findex/shopinfo', $this->ret)->filter($this->filter);
    }
    public function goodsinfo(){

        $id = Request::param("id");

        $this->ret['goods'] = Db::table("goods")->where([["id", "=", $id]])->find();

        $this->ret['tgoods'] = Db::table("goods")->limit(5)->select()->toArray();

        return view('findex/goodsinfo', $this->ret)->filter($this->filter);
    }
    public function delCar(){
        $id = Request::param("id");
        Db::table("car")->where(["id" => $id])->delete();
        Base::redirect(url('/success'), url("index/usercenter"), "delete success!！", "car page", 1);
    }
}