<?php
namespace app\controller;

use app\controller\Base;

use think\facade\Request;
use think\facade\Db;
use think\facade\Session;

class User extends Base
{
    /**
     * indexpage
     */
    public function login(){

        $name = Request::param('name');
        $pwd = Request::param('pwd');

        $userInfo = Db::table("user")->where(["name"=>$name])->find();

        if(empty($userInfo)){
            //不存在
            Base::redirect(url('/error'), url("/admin"), "This user does not exist!");
        }else{
            if($userInfo['pwd'] != md5($pwd)){
                Base::redirect(url('/error'), url("/admin"),"password error！");
            }
            //注入session
            $_SESSION[$this->master_name] = $userInfo['id'];

            Base::redirect(url('/success'), url("/adminindex"), "login success!，Is about to jump toindexpage", "indexpage");
        }
    }
    /**
     *  logout 
     */
    public function logout(){

        unset($_SESSION[$this->master_name]);

        Base::redirect(url('/'));
    }
    /**
     * people员list 
     */
    public function userlist(){

        return view('admin/user/userlist',$this->ret)->filter($this->filter);
    }
    /**
     *  add 五register码
     */
    public function addreg(){

        for($i=0;$i<5;$i++){

            $add[] = ["mark"=>md5(time().rand(10000,99999).$i)];
        }

        // add 
        Db::table("user")->insertAll($add);

        Base::redirect(url('/userlist'));
    }
    public function addIn(){

        $add = Request::param();

        // add 
        Db::table("user")->insert($add);

        Base::redirect(url('/success'),url("/list"),"add  success!","list page");
    }
    public function delUser(){

        $id = Request::param("id");

        Db::table("user")->where("id",$id)->delete();

        Base::redirect(url('/success'),url("/list"),"delete success!","list page");
    }
}
