<?php
namespace app\controller;

use app\controller\Base;
use think\facade\Db;
use think\facade\Request;

class Active extends Base
{
    /**
     * index
     */
    public function index(){

        $q = Request::param("q", "");

        $pageRe = 15;

        $where = [];

        if ($q != "") {

            $where[] = ["name", "like", "%" . (string)trim($q) . "%"];
        }

        $list = Db::table("user")->where($where)->order('id', 'desc')->paginate($pageRe);

        $team = Db::table("team")->select();

        $this->ret['page'] = $list->render();

        $this->ret['items'] = $list->items();

        $this->ret['team'] = $team;

        return view('admin/active/index', $this->ret)->filter($this->filter);
    }
    /**
     * add
     */
    public function add(){

        $data = Request::param();

        $data['pwd'] = md5($data['pwd']);

        $user = Db::table("user")->where(['name'=>$data['name']])->find();

        if(!empty($user)){

            Base::redirect(url('/error'), url("/active"), "have same username！plase change other name!", "user list page");
        }

        $res = Db::table("user")->insert($data);

        if ($res) {

            Base::redirect(url('/success'), url("/active"), "user add  success!！", "user list page");
        } else {

            Base::redirect(url('/error'), url("/active"), "user add fail！", "user list page");
        }

    }
    /**
     * delactive
     */
    public function delactive(){

        $id = Request::param("id");

        $res = Db::table("user")->where(["id" => $id])->delete();

        if ($res) {

            Base::redirect(url('/success'), url("/active"), "user  success!！", "user list page");
        } else {

            Base::redirect(url('/error'), url("/active"), "user fail！", "user list page");
        }
    }
}