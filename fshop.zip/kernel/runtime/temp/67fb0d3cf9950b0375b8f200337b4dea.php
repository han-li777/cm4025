<?php /*a:4:{s:42:"E:\out\fshop\kernel\view\findex\login.html";i:1615618517;s:47:"E:\out\fshop\kernel\view\admin\common\head.html";i:1615627056;s:41:"E:\out\fshop\kernel\view\findex\head.html";i:1615772176;s:40:"E:\out\fshop\kernel\view\findex\nav.html";i:1615621980;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlentities($webtitle); ?></title>
    <link rel="shortcut icon" type="image/x-icon"
        href="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" />

    <!--jquery-->
    <script src="<?php echo htmlentities($rootadr); ?>/static/js/jquery.min.js"></script>

    <!--bootstrap-->
    <link href="<?php echo htmlentities($rootadr); ?>/static/css/bootstrap.min.css" rel="stylesheet">
    <script src="<?php echo htmlentities($rootadr); ?>/static/js/bootstrap.min.js"></script>

    <!--baidu echarts-->
    <script src="<?php echo htmlentities($rootadr); ?>/static/js/echars.min.js"></script>

</head>
<style>
    html {
        font-size: 15px;
        width: 100%;
        height: 100%;
    }

    body {
        font-size: 15px;
        width: 100%;
        height: 100%;
        font-size: 12px;
        font-family: '微软雅黑';
        background: url('<?php echo htmlentities($rootadr); ?>/imgsrc/bangoundcolor.png');
        background-size:100% 100%;
    }

    .main_div {
        float: left;
        width: calc(100% - 240px);
        margin-left: 15px;
        margin-right: 15px;
        height: calc(100% - 60px);
        margin-top: 57px;
        background-color: aliceblue;
        overflow: auto;
    }

    .main_div_content {
        margin-left: 10px;
        margin-right: 10px;
        margin-top: 10px;
    }

    .main_div::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .main_div::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .main_div::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .maxf::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .maxf::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .maxf::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .td_mx {
        white-space: nowrap;
        /*文本不会换行，在同一行显示*/
        overflow: hidden;
        /*超出隐藏 */
        text-overflow: ellipsis;
        /*省略code显示*/
        -o-text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        -webkit-text-overflow: ellipsis;
    }

    .mtable {
        margin: 0 auto;
        width: 850px;
        margin-top: 20px;
        margin-bottom: 20px;
        font-family: "微软雅黑";
        table-layout: fixed;
    }

    .mtable_td {
        border-bottom: 10px solid #666666;
        /*下面4行是实现超过td文字变省略code,另外还要给table加上table-layout:fixed;*/
        text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    /*大型模态框*/
    .big_dog_div{
        width: 100%;overflow-x:hidden;
    }
    .big_dog_conetnt{
        width: 80%;margin-left: 10%;
    }
</style>

<body>
    <style>
        .main_findex {
            width: 1000px;
            height: auto;
            min-height: 950px;
            background-color: azure;
            margin-top: 10px;
            margin-bottom: 50px;
        }

        .main_findex_list {
            text-align: left;
            margin-left: 10px;
        }
    </style>
    <center>
        <div class="main_findex">
            <div style="height:80px">
    <h3 style="margin-top:20px;float:left;margin-left:15px;">
        <img alt="" src="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" width="50px">
        <?php echo htmlentities($webtitle); ?>
    </h3>
    <?php 
    if(!isset($_SESSION['logins'])){
     ?>
    <p style="float:right;margin-top:50px;margin-right:15px;">
            <?php echo "tourist".strtotime(date('Y-m-d')); ?>
            <a href="<?php echo url('index/reg'); ?>">register</a>/<a
            href="<?php echo url('index/login'); ?>">login </a> </p>
    <?php 
    }else{
     ?>
    <p style="float:right;margin-top:50px;margin-right:15px;"><a href="<?php echo url('index/usercenter'); ?>">people center </a>/<a
            href="<?php echo url('index/logout'); ?>"> logout </a> </p>
    <?php 
    }
     ?>
</div>
            <nav class="navbar navbar-default navbar-inverse">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            </button>
            <a class="navbar-brand" href="<?php echo url('index/'); ?>">Index</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo url('index/goods'); ?>">goods-list</a></li>
                <li><a href="<?php echo url('/admin'); ?>">back-end</a></li>
            </ul>
            <form class="navbar-form navbar-left" method="GET" action="<?php echo url('index/q'); ?>">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Enter the name of the product" name="q">
                </div>
                <button type="submit" class="btn btn-default">search</button>
            </form>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
            <h4>
                login
            </h4>
            <hr />
            <br />
            <form method="post" action="<?php echo url('index/logina'); ?>">
                <div style="width:450px;text-align:left;">
                    <label>name</label>
                    <input class="form-control" type="text" name="username" />
                    <label>password</label>
                    <input class="form-control" type="password" name="password" />
                    <br />
                    <button class="btn btn-primary" type="submit">login</button>
                </div>
            </form>
        </div>
    </center>
</body>
<script>

</script>

</html>
