<?php /*a:4:{s:55:"E:\out\a_eshop\eshop\kernel\view\findex\usercenter.html";i:1614128563;s:55:"E:\out\a_eshop\eshop\kernel\view\admin\common\head.html";i:1613614106;s:49:"E:\out\a_eshop\eshop\kernel\view\findex\head.html";i:1613637829;s:48:"E:\out\a_eshop\eshop\kernel\view\findex\nav.html";i:1613637923;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlentities($webtitle); ?></title>
    <link rel="shortcut icon" type="image/x-icon"
        href="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" />

    <!--jquery-->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!--bootstrap-->
    <link href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!--wangeditor富文本编辑器-->
    <script src="https://cdn.bootcdn.net/ajax/libs/wangEditor/10.0.13/wangEditor.min.js"></script>
    <link href="https://cdn.bootcdn.net/ajax/libs/wangEditor/10.0.13/wangEditor.min.css" rel="stylesheet">

    <!--vue-->
    <script src="https://cdn.bootcss.com/vue/2.6.11/vue.min.js"></script>

    <!--上传插件-->
    <script src="https://cdn.bootcss.com/plupload/3.1.2/plupload.full.min.js"></script>
    <!--baidu echarts-->
    <script src="https://cdn.bootcdn.net/ajax/libs/echarts/4.8.0/echarts.min.js"></script>

    <!--time戳插件-->
    <script src="https://lcjytp.oss-cn-beijing.aliyuncs.com/js_res/jquery.jedate.min.js"></script>
    <link href="https://lcjytp.oss-cn-beijing.aliyuncs.com/js_res/jedate.css" rel="stylesheet">

    <!--树状图插件-->
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.css" rel="stylesheet">
    <script src="https://cdn.bootcdn.net/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.js"></script>

    <!--jquery 对话框插件-->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery-confirm/3.3.4/jquery-confirm.min.js"></script>

    <!--jquery json-->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery-jsonview/1.2.3/jquery.jsonview.min.js"></script>
    <link href="https://cdn.bootcdn.net/ajax/libs/jquery-jsonview/1.2.3/jquery.jsonview.min.css" rel="stylesheet">

</head>
<style>
    html {
        font-size: 15px;
        width: 100%;
        height: 100%;
    }

    body {
        font-size: 15px;
        width: 100%;
        height: 100%;
        font-size: 12px;
        font-family: '微软雅黑';
        background: url('<?php echo htmlentities($rootadr); ?>/imgsrc/bangoundcolor.png');
        background-size:100% 100%;
    }

    .main_div {
        float: left;
        width: calc(100% - 240px);
        margin-left: 15px;
        margin-right: 15px;
        height: calc(100% - 60px);
        margin-top: 57px;
        background-color: aliceblue;
        overflow: auto;
    }

    .main_div_content {
        margin-left: 10px;
        margin-right: 10px;
        margin-top: 10px;
    }

    .main_div::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .main_div::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .main_div::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .maxf::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .maxf::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .maxf::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .td_mx {
        white-space: nowrap;
        /*文本不会换行，在同一行显示*/
        overflow: hidden;
        /*超出隐藏 */
        text-overflow: ellipsis;
        /*省略code显示*/
        -o-text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        -webkit-text-overflow: ellipsis;
    }

    .mtable {
        margin: 0 auto;
        width: 850px;
        margin-top: 20px;
        margin-bottom: 20px;
        font-family: "微软雅黑";
        table-layout: fixed;
    }

    .mtable_td {
        border-bottom: 10px solid #666666;
        /*下面4行是实现超过td文字变省略code,另外还要给table加上table-layout:fixed;*/
        text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    /*大型模态框*/
    .big_dog_div{
        width: 100%;overflow-x:hidden;
    }
    .big_dog_conetnt{
        width: 80%;margin-left: 10%;
    }
</style>

<body>
    <style>
        .main_findex {
            width: 1000px;
            height: auto;
            min-height: 950px;
            background-color: azure;
            margin-top: 10px;
            margin-bottom: 50px;
        }

        .main_findex_list {
            text-align: left;
            margin-left: 10px;
        }
    </style>
    <center>
        <div class="main_findex">
            <div style="height:80px">
    <h3 style="margin-top:20px;float:left;margin-left:15px;">
        <img alt="" src="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" width="50px">
        <?php echo htmlentities($webtitle); ?>
    </h3>
    <?php 
    if(!isset($_SESSION['logins'])){
     ?>
    <p style="float:right;margin-top:50px;margin-right:15px;">
            <?php echo "tourist".strtotime(date('Y-m-d')); ?>
            <a href="<?php echo url('index/reg'); ?>">register</a>/<a
            href="<?php echo url('index/login'); ?>">login </a> </p>
    <?php 
    }else{
     ?>
    <p style="float:right;margin-top:50px;margin-right:15px;"><a href="<?php echo url('index/usercenter'); ?>">people center </a>/<a
            href="<?php echo url('index/logout'); ?>"> logout </a> </p>
    <?php 
    }
     ?>
</div>
            <nav class="navbar navbar-default navbar-inverse">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            </button>
            <a class="navbar-brand" href="<?php echo url('index/'); ?>">indexpage</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo url('index/goods'); ?>">goods list </a></li>
                <li><a href="<?php echo url('index/shops'); ?>">shoplist </a></li>
                <li><a href="<?php echo url('/admin'); ?>">管理后台</a></li>
            </ul>
            <form class="navbar-form navbar-left" method="GET" action="<?php echo url('index/q'); ?>">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="inputgoods name" name="q">
                </div>
                <button type="submit" class="btn btn-default">search</button>
            </form>
            <form class="navbar-form navbar-left" method="GET" action="<?php echo url('index/qs'); ?>">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="inputshopname" name="qs">
                </div>
                <button type="submit" class="btn btn-default">search</button>
            </form>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
            <h4>
                people center 
            </h4>
            <hr />
            <br />
            <div style="text-align:left;margin-left:15px;">
            <h4>name ：<?php echo htmlentities($username); ?></h4>
            <h4>ID：<?php echo htmlentities($id); ?></h4>
            <hr />
            <h4>
                car ：
                <a href="<?php echo url('index/clearcar'); ?>">
                <button class="btn btn-danger btn-xs">settlement</button>
                </a>
            </h4>
            <br />
            <?php foreach($car as $key=>$vo): ?>
            <div class="main_findex_list">
                <div class="media">
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo htmlentities($vo['goodsname']); ?></h4>
                        <h4>price：<?php echo htmlentities($vo['price']); ?>$</h4>
                        <p>time：<?php echo htmlentities($vo['add_time']); ?></p>
                    </div>
                </div>
                <a href="<?php echo url('index/del_car'); ?>?id=<?php echo htmlentities($vo['id']); ?>">
                    <button class="btn btn-info btn-xs">deletegoods </button>
                </a>
            </div>
            <hr />
            <?php endforeach; ?>
            <h4>my order</h4>
            <?php foreach($order as $key=>$vo): ?>
            <div class="main_findex_list">
                <div class="media">
                    <div class="media-body">
                        <h4 class="media-heading">ordercode：<?php echo htmlentities($vo['sn']); ?></h4>
                        <h4>The total price：<?php echo htmlentities($vo['price']); ?>$</h4>
                        <p>goods id：<?php echo htmlentities($vo['goodis']); ?></p>
                        <p>time：<?php echo htmlentities($vo['add_time']); ?></p>
                    </div>
                </div>
            </div>
            <hr />
            <?php endforeach; ?>
            </div>
        </div>
    </center>
</body>
<script>

</script>

</html>
