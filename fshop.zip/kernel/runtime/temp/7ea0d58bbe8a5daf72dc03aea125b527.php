<?php /*a:3:{s:49:"E:\out\fshop\kernel\view\admin\index\welcome.html";i:1615619185;s:47:"E:\out\fshop\kernel\view\admin\common\head.html";i:1615627056;s:49:"E:\out\fshop\kernel\view\admin\common\footer.html";i:1613614106;}*/ ?>
<!doctype html>
<html>
	<head>
    <title><?php echo htmlentities($webtitle); ?></title>
    <link rel="shortcut icon" type="image/x-icon"
        href="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" />

    <!--jquery-->
    <script src="<?php echo htmlentities($rootadr); ?>/static/js/jquery.min.js"></script>

    <!--bootstrap-->
    <link href="<?php echo htmlentities($rootadr); ?>/static/css/bootstrap.min.css" rel="stylesheet">
    <script src="<?php echo htmlentities($rootadr); ?>/static/js/bootstrap.min.js"></script>

    <!--baidu echarts-->
    <script src="<?php echo htmlentities($rootadr); ?>/static/js/echars.min.js"></script>

</head>
<style>
    html {
        font-size: 15px;
        width: 100%;
        height: 100%;
    }

    body {
        font-size: 15px;
        width: 100%;
        height: 100%;
        font-size: 12px;
        font-family: '微软雅黑';
        background: url('<?php echo htmlentities($rootadr); ?>/imgsrc/bangoundcolor.png');
        background-size:100% 100%;
    }

    .main_div {
        float: left;
        width: calc(100% - 240px);
        margin-left: 15px;
        margin-right: 15px;
        height: calc(100% - 60px);
        margin-top: 57px;
        background-color: aliceblue;
        overflow: auto;
    }

    .main_div_content {
        margin-left: 10px;
        margin-right: 10px;
        margin-top: 10px;
    }

    .main_div::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .main_div::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .main_div::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .maxf::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .maxf::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .maxf::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .td_mx {
        white-space: nowrap;
        /*文本不会换行，在同一行显示*/
        overflow: hidden;
        /*超出隐藏 */
        text-overflow: ellipsis;
        /*省略code显示*/
        -o-text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        -webkit-text-overflow: ellipsis;
    }

    .mtable {
        margin: 0 auto;
        width: 850px;
        margin-top: 20px;
        margin-bottom: 20px;
        font-family: "微软雅黑";
        table-layout: fixed;
    }

    .mtable_td {
        border-bottom: 10px solid #666666;
        /*下面4行是实现超过td文字变省略code,另外还要给table加上table-layout:fixed;*/
        text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    /*大型模态框*/
    .big_dog_div{
        width: 100%;overflow-x:hidden;
    }
    .big_dog_conetnt{
        width: 80%;margin-left: 10%;
    }
</style>
	<style>
		.content-main{
			box-shadow: 5px 5px 3px #DBDBD9;
			height:350px;background-color: #ffffff;filter:alpha(opacity=30);opacity:.9;border-radius:10px;
		}
	</style>
	<body>
        <div style="width: 100%;height: 100%;">
            <br /><br /><br /><br /><br /><br /><br /><br />
            <div style="margin-left:60%;width: 450px;">
                <div align="center" class="content-main">
                    <br /><br />
                    <h5>
                        <img alt="" src="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" width="50px">
                        <?php echo htmlentities($webtitle); ?>
                    </h5>
                    <br />
                    <form style="width:350px;text-align: left;height: 550px;" method="post" action="<?php echo url('/login'); ?>">
                    <div class="form-group">
                        <label for="exampleInputEmail1">plase input administrator account</label>
                        <input type="text" class="form-control" name="name">
                        <label for="exampleInputEmail1">plase input administrator password</label>
                        <input type="password" class="form-control" name="pwd">
                    </div>
                    <br />
                    <button type="submit" class="btn btn-info">login</button>
                    </form>
                </div>
            </div>
        </div>
		<div style="position:fixed; bottom:0;">
    <p style="font-size:8px;color: #ffffff;margin-left:20px;">
        Copyright 2016-2020 <?php echo htmlentities($webtitle); ?> . All Rights Reserved.
    </p>
</div>
	</body>
</html>
