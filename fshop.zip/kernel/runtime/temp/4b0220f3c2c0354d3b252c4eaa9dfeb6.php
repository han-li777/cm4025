<?php /*a:4:{s:55:"E:\out\a_eshop\eshop\kernel\view\admin\index\index.html";i:1613641214;s:55:"E:\out\a_eshop\eshop\kernel\view\admin\common\head.html";i:1613614106;s:55:"E:\out\a_eshop\eshop\kernel\view\admin\common\left.html";i:1613633053;s:54:"E:\out\a_eshop\eshop\kernel\view\admin\common\top.html";i:1613614106;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlentities($webtitle); ?></title>
    <link rel="shortcut icon" type="image/x-icon"
        href="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" />

    <!--jquery-->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!--bootstrap-->
    <link href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!--wangeditor富文本编辑器-->
    <script src="https://cdn.bootcdn.net/ajax/libs/wangEditor/10.0.13/wangEditor.min.js"></script>
    <link href="https://cdn.bootcdn.net/ajax/libs/wangEditor/10.0.13/wangEditor.min.css" rel="stylesheet">

    <!--vue-->
    <script src="https://cdn.bootcss.com/vue/2.6.11/vue.min.js"></script>

    <!--上传插件-->
    <script src="https://cdn.bootcss.com/plupload/3.1.2/plupload.full.min.js"></script>
    <!--baidu echarts-->
    <script src="https://cdn.bootcdn.net/ajax/libs/echarts/4.8.0/echarts.min.js"></script>

    <!--time戳插件-->
    <script src="https://lcjytp.oss-cn-beijing.aliyuncs.com/js_res/jquery.jedate.min.js"></script>
    <link href="https://lcjytp.oss-cn-beijing.aliyuncs.com/js_res/jedate.css" rel="stylesheet">

    <!--树状图插件-->
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.css" rel="stylesheet">
    <script src="https://cdn.bootcdn.net/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.js"></script>

    <!--jquery 对话框插件-->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery-confirm/3.3.4/jquery-confirm.min.js"></script>

    <!--jquery json-->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery-jsonview/1.2.3/jquery.jsonview.min.js"></script>
    <link href="https://cdn.bootcdn.net/ajax/libs/jquery-jsonview/1.2.3/jquery.jsonview.min.css" rel="stylesheet">

</head>
<style>
    html {
        font-size: 15px;
        width: 100%;
        height: 100%;
    }

    body {
        font-size: 15px;
        width: 100%;
        height: 100%;
        font-size: 12px;
        font-family: '微软雅黑';
        background: url('<?php echo htmlentities($rootadr); ?>/imgsrc/bangoundcolor.png');
        background-size:100% 100%;
    }

    .main_div {
        float: left;
        width: calc(100% - 240px);
        margin-left: 15px;
        margin-right: 15px;
        height: calc(100% - 60px);
        margin-top: 57px;
        background-color: aliceblue;
        overflow: auto;
    }

    .main_div_content {
        margin-left: 10px;
        margin-right: 10px;
        margin-top: 10px;
    }

    .main_div::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .main_div::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .main_div::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .maxf::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .maxf::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .maxf::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .td_mx {
        white-space: nowrap;
        /*文本不会换行，在同一行显示*/
        overflow: hidden;
        /*超出隐藏 */
        text-overflow: ellipsis;
        /*省略code显示*/
        -o-text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        -webkit-text-overflow: ellipsis;
    }

    .mtable {
        margin: 0 auto;
        width: 850px;
        margin-top: 20px;
        margin-bottom: 20px;
        font-family: "微软雅黑";
        table-layout: fixed;
    }

    .mtable_td {
        border-bottom: 10px solid #666666;
        /*下面4行是实现超过td文字变省略code,另外还要给table加上table-layout:fixed;*/
        text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    /*大型模态框*/
    .big_dog_div{
        width: 100%;overflow-x:hidden;
    }
    .big_dog_conetnt{
        width: 80%;margin-left: 10%;
    }
</style>

<body>
    <style>
    .left_div{
        width: 210px;
        text-align: center;
        float: left;
    }
    .left_li{
        cursor: pointer;
    }
    .left_li:hover{
        cursor: pointer;
        color: blue;
    }
</style>
<div class="left_div">
    <ul class="list-group">
        <li class="list-group-item left_li"><img src="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" width="30px"><b style="font-size: 13px;"><?php echo htmlentities($webtitle); ?></b></li>
        <?php foreach($left as $key=>$vo): if($vo['rank'] == 0 or $vo['rank'] == $rank){
             ?>
        <a href="<?php echo url($vo['path']); ?>">
            <li class="
            list-group-item left_li
            <?php if($vo['adr'] == $adr): ?>active<?php endif; ?>
            "><?php echo htmlentities($vo['name']); ?></li>
        </a>
        <?php } ?>
        <?php endforeach; ?>
        <a href="<?php echo url('/logout'); ?>">
            <li class="list-group-item left_li"> logout  account</li>
        </a>
    </ul>
</div>
    <nav class="navbar navbar-default navbar-fixed-top" style="width: calc(100% - 240px);margin-left:225px;">
    <div class="container-fluid">
        <ul class="nav nav-pills" style="margin-top: 4px;">
            <li role="presentation" style="margin-top: 10px;">
                <?php echo htmlentities($usertitle); ?>
            </li>
            <?php foreach($top as $key=>$vo): ?>
                <li role="presentation" class="<?php if($vo['path'] == $route_path): ?>active<?php endif; ?>">
                    <a href="<?php echo url($vo['path']); ?>">
                        <?php echo htmlentities($vo['name']); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</nav>
    <div class="main_div">
        <div class="main_div_content">
            <form method="GET" action="<?php echo url('/list'); ?>" class="form-group" style="margin-top: 15px;">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="inputshopnamesearch" name="q"
                                style="width:200px;">
                            <span class="input-group-btn" style="float: left;">
                                <button class="btn btn-primary" type="submit">search</button>
                            </span>
                    </div>
                </div>
            </form>
            <br />
            <br />
            <table class="table table-striped table-bordered table-hover table-sm mtable"
                style="margin-top: 15px;width: 100%;margin-left: 15px;">
                <thead>
                    <tr class="info">
                        <th scope="col" >#</th>
                        <th scope="col" >shopname</th>
                        <th scope="col" >shop所属peopleid</th>
                        <th scope="col" >shop建立time</th>
                        <th scope="col">shopupdatetime</th>
                        <th scope="col"> operation</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <form action="<?php echo url('/addteam'); ?>" method="POST">
                            <th scope="row" style="width: 50px;">
                                #
                            </th>
                            <td style="width: 100px;">
                                <input class="form-control" type="text" name="name">    
                            </td>
                            <td style="width: 400px;">
                                <input class="form-control" type="text" name="belong">
                            </td>
                            <td style="width: 400px;"></td>
                            <td></td>
                            <td>
                                <button type="submit" class="btn btn-success btn-xs"> add </button>
                            </td>
                        </form>
                    </tr>
                    <?php foreach($items as $key=>$vo): ?>
                    <tr>
                        <th scope="row" ><?php echo htmlentities($vo['id']); ?></th>
                        <td><?php echo htmlentities($vo['name']); ?></td>
                        <td><?php echo htmlentities($vo['belong']); ?></td>
                        <td><?php echo htmlentities($vo['add_time']); ?></td>
                        <td><?php echo htmlentities($vo['update_time']); ?></td>
                        <td>
                            <a href="<?php echo url('/delteam'); ?>?id=<?php echo htmlentities($vo['id']); ?>">
                                <button type="button" class="btn btn-danger btn-xs">delete</button>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php echo $page; ?>
        </div>
    </div>
</body>
<script>

</script>

</html>