<?php /*a:4:{s:52:"E:\out\fshop\kernel\view\admin\index\adminindex.html";i:1615772894;s:47:"E:\out\fshop\kernel\view\admin\common\head.html";i:1615627056;s:47:"E:\out\fshop\kernel\view\admin\common\left.html";i:1615619057;s:46:"E:\out\fshop\kernel\view\admin\common\top.html";i:1613614106;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlentities($webtitle); ?></title>
    <link rel="shortcut icon" type="image/x-icon"
        href="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" />

    <!--jquery-->
    <script src="<?php echo htmlentities($rootadr); ?>/static/js/jquery.min.js"></script>

    <!--bootstrap-->
    <link href="<?php echo htmlentities($rootadr); ?>/static/css/bootstrap.min.css" rel="stylesheet">
    <script src="<?php echo htmlentities($rootadr); ?>/static/js/bootstrap.min.js"></script>

    <!--baidu echarts-->
    <script src="<?php echo htmlentities($rootadr); ?>/static/js/echars.min.js"></script>

</head>
<style>
    html {
        font-size: 15px;
        width: 100%;
        height: 100%;
    }

    body {
        font-size: 15px;
        width: 100%;
        height: 100%;
        font-size: 12px;
        font-family: '微软雅黑';
        background: url('<?php echo htmlentities($rootadr); ?>/imgsrc/bangoundcolor.png');
        background-size:100% 100%;
    }

    .main_div {
        float: left;
        width: calc(100% - 240px);
        margin-left: 15px;
        margin-right: 15px;
        height: calc(100% - 60px);
        margin-top: 57px;
        background-color: aliceblue;
        overflow: auto;
    }

    .main_div_content {
        margin-left: 10px;
        margin-right: 10px;
        margin-top: 10px;
    }

    .main_div::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .main_div::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .main_div::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .maxf::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .maxf::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .maxf::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .td_mx {
        white-space: nowrap;
        /*文本不会换行，在同一行显示*/
        overflow: hidden;
        /*超出隐藏 */
        text-overflow: ellipsis;
        /*省略code显示*/
        -o-text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        -webkit-text-overflow: ellipsis;
    }

    .mtable {
        margin: 0 auto;
        width: 850px;
        margin-top: 20px;
        margin-bottom: 20px;
        font-family: "微软雅黑";
        table-layout: fixed;
    }

    .mtable_td {
        border-bottom: 10px solid #666666;
        /*下面4行是实现超过td文字变省略code,另外还要给table加上table-layout:fixed;*/
        text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    /*大型模态框*/
    .big_dog_div{
        width: 100%;overflow-x:hidden;
    }
    .big_dog_conetnt{
        width: 80%;margin-left: 10%;
    }
</style>

<body>
    <style>
    .left_div{
        width: 210px;
        text-align: center;
        float: left;
    }
    .left_li{
        cursor: pointer;
    }
    .left_li:hover{
        cursor: pointer;
        color: blue;
    }
</style>
<div class="left_div">
    <ul class="list-group">
        <li class="list-group-item left_li"><img src="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" width="30px"><b style="font-size: 13px;"><?php echo htmlentities($webtitle); ?></b></li>
        <?php foreach($left as $key=>$vo): if($vo['rank'] == 0 or $vo['rank'] == $rank){
             ?>
        <a href="<?php echo url($vo['path']); ?>">
            <li class="
            list-group-item left_li
            <?php if($vo['adr'] == $adr): ?>active<?php endif; ?>
            "><?php echo htmlentities($vo['name']); ?></li>
        </a>
        <?php } ?>
        <?php endforeach; ?>
        <a href="<?php echo url('/logout'); ?>">
            <li class="list-group-item left_li"> logout  account</li>
        </a>
    </ul>
</div>
    <nav class="navbar navbar-default navbar-fixed-top" style="width: calc(100% - 240px);margin-left:225px;">
    <div class="container-fluid">
        <ul class="nav nav-pills" style="margin-top: 4px;">
            <li role="presentation" style="margin-top: 10px;">
                <?php echo htmlentities($usertitle); ?>
            </li>
            <?php foreach($top as $key=>$vo): ?>
                <li role="presentation" class="<?php if($vo['path'] == $route_path): ?>active<?php endif; ?>">
                    <a href="<?php echo url($vo['path']); ?>">
                        <?php echo htmlentities($vo['name']); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</nav>
    <div class="main_div">
        <div class="main_div_content">
            <h3>A/S-info</h3>
            <div id="main" style="width:800px;height:600px;float:left;"></div>
            <div id="main1" style="width: 600px;height:400px;float:left;"></div>
            <script type="text/javascript">

                var myChart = echarts.init(document.getElementById('main'));

                option = {
                    title: {
                        text: 'User access data'
                    },
                    series: [{
                        type: 'gauge',
                        startAngle: 90,
                        endAngle: -270,
                        pointer: {
                            show: false
                        },
                        progress: {
                            show: true,
                            overlap: false,
                            roundCap: true,
                            clip: false,
                            itemStyle: {
                                borderWidth: 1,
                                borderColor: '#168944'
                            }
                        },
                        axisLine: {

                            lineStyle: {
                                width: 40
                            }
                        },
                        splitLine: {
                            show: false,
                            distance: 0,
                            length: 10
                        },
                        axisTick: {
                            show: false
                        },
                        axisLabel: {
                            show: false,
                            distance: 50
                        },
                        data: [{
                            value: 20,
                            name: 'Percentage of shoppers',
                            title: {
                                offsetCenter: ['0%', '-30%']
                            },
                            detail: {
                                offsetCenter: ['0%', '-20%']
                            }
                        },
                        ],
                        title: {
                            fontSize: 14
                        },
                        detail: {
                            width: 50,
                            height: 14,
                            fontSize: 14,
                            color: 'auto',
                            borderColor: 'auto',
                            borderRadius: 20,
                            borderWidth: 1,
                            formatter: '{value}%'
                        }
                    }]
                };

                option.series[0].pointer.show = false;
                option.series[0].data[0].value = <?php echo htmlentities($userlv); ?>;
                myChart.setOption(option, true);
            </script>
            <script type="text/javascript">

                var myChart1 = echarts.init(document.getElementById('main1'));

                var option1 = {
                    title: {
                        text: 'User Visit Nums'
                    },
                    tooltip: {},
                    legend: {
                        data:['nums']
                    },
                    xAxis: {
                        data: [<?php echo htmlentities($userae); ?>]
                    },
                    yAxis: {},
                    series: [{
                        name: 'price',
                        type: 'bar',
                        data: [<?php echo htmlentities($userle); ?>]
                    }]
                };

                myChart1.setOption(option1);
            </script>
        </div>
    </div>
</body>
<script>

</script>

</html>