<?php /*a:2:{s:56:"E:\out\a_eshop\eshop\kernel\view\admin\status\error.html";i:1613614106;s:55:"E:\out\a_eshop\eshop\kernel\view\admin\common\head.html";i:1613614106;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlentities($webtitle); ?></title>
    <link rel="shortcut icon" type="image/x-icon"
        href="<?php echo htmlentities($rootadr); ?>/imgsrc/logo.png" />

    <!--jquery-->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!--bootstrap-->
    <link href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!--wangeditor富文本编辑器-->
    <script src="https://cdn.bootcdn.net/ajax/libs/wangEditor/10.0.13/wangEditor.min.js"></script>
    <link href="https://cdn.bootcdn.net/ajax/libs/wangEditor/10.0.13/wangEditor.min.css" rel="stylesheet">

    <!--vue-->
    <script src="https://cdn.bootcss.com/vue/2.6.11/vue.min.js"></script>

    <!--上传插件-->
    <script src="https://cdn.bootcss.com/plupload/3.1.2/plupload.full.min.js"></script>
    <!--baidu echarts-->
    <script src="https://cdn.bootcdn.net/ajax/libs/echarts/4.8.0/echarts.min.js"></script>

    <!--time戳插件-->
    <script src="https://lcjytp.oss-cn-beijing.aliyuncs.com/js_res/jquery.jedate.min.js"></script>
    <link href="https://lcjytp.oss-cn-beijing.aliyuncs.com/js_res/jedate.css" rel="stylesheet">

    <!--树状图插件-->
    <link href="https://cdn.bootcdn.net/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.css" rel="stylesheet">
    <script src="https://cdn.bootcdn.net/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.js"></script>

    <!--jquery 对话框插件-->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery-confirm/3.3.4/jquery-confirm.min.js"></script>

    <!--jquery json-->
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery-jsonview/1.2.3/jquery.jsonview.min.js"></script>
    <link href="https://cdn.bootcdn.net/ajax/libs/jquery-jsonview/1.2.3/jquery.jsonview.min.css" rel="stylesheet">

</head>
<style>
    html {
        font-size: 15px;
        width: 100%;
        height: 100%;
    }

    body {
        font-size: 15px;
        width: 100%;
        height: 100%;
        font-size: 12px;
        font-family: '微软雅黑';
        background: url('<?php echo htmlentities($rootadr); ?>/imgsrc/bangoundcolor.png');
        background-size:100% 100%;
    }

    .main_div {
        float: left;
        width: calc(100% - 240px);
        margin-left: 15px;
        margin-right: 15px;
        height: calc(100% - 60px);
        margin-top: 57px;
        background-color: aliceblue;
        overflow: auto;
    }

    .main_div_content {
        margin-left: 10px;
        margin-right: 10px;
        margin-top: 10px;
    }

    .main_div::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .main_div::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .main_div::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .maxf::-webkit-scrollbar {
        /*滚动条整体样式*/
        width: 6px;
        /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }

    .maxf::-webkit-scrollbar-thumb {
        /*滚动条里面小方块*/
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        background: #7a7878;
    }

    .maxf::-webkit-scrollbar-track {
        /*滚动条里面轨道*/
        box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        background: #ededed;
    }

    .td_mx {
        white-space: nowrap;
        /*文本不会换行，在同一行显示*/
        overflow: hidden;
        /*超出隐藏 */
        text-overflow: ellipsis;
        /*省略code显示*/
        -o-text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        -webkit-text-overflow: ellipsis;
    }

    .mtable {
        margin: 0 auto;
        width: 850px;
        margin-top: 20px;
        margin-bottom: 20px;
        font-family: "微软雅黑";
        table-layout: fixed;
    }

    .mtable_td {
        border-bottom: 10px solid #666666;
        /*下面4行是实现超过td文字变省略code,另外还要给table加上table-layout:fixed;*/
        text-overflow: ellipsis;
        -moz-text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    /*大型模态框*/
    .big_dog_div{
        width: 100%;overflow-x:hidden;
    }
    .big_dog_conetnt{
        width: 80%;margin-left: 10%;
    }
</style>

<body>
    <style>
        .err_div {
            box-shadow: 10px 10px 5px #888888;
        }
    </style>
    <center>
        <div style="margin-top: 270px;width: 400px;background-color: #ffffff;height: 250px;border-radius:25px;-moz-border-radius:25px;"
            class="err_div">
            <br />
            <hr />
            <h4><b><?php echo htmlentities($message); ?></b></h4>
            <hr />
            <p>Is about to jump to<span><?php echo $adrUrl; ?></span></p>
            <a class="btn btn-danger" href="#" role="button" id="btn" onclick="go()">3s</a>
            <hr />
            <br />
        </div>
    </center>
</body>
<script>
    function go() {

        window.location.href = '<?php echo $goUrl; ?>';
    }

    $(function () {
        var btn = document.getElementById('btn')
        var a = true;
        var len = <?php echo $goTime;  ?>;
            btn.innerHTML = len + 's';
            var time = setInterval(function () {
                btn.innerHTML = parseFloat(btn.innerHTML) - 1 + 's'
                if (btn.innerHTML == '0s') {

                    window.location.href = '<?php echo $goUrl; ?>';
                }
            }, 1000);
            a = false;
        }); 
</script>

</html>